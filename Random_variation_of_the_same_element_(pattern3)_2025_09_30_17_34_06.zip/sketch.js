function setup() {
  createCanvas(400, 400);
  stroke(0, 150);
}

function draw() {
  background(255);

  let numElements = 20;
  let spacing = width / numElements;

  for (let i = 0; i < numElements; i++) {
    for (let j = 0; j < numElements; j++) {
      let x = spacing / 2 + i * spacing;
      let y = spacing / 2 + j * spacing;

      push();
      translate(x, y);

      // Use Perlin noise to get a smooth, evolving random value.
      // The i and j values give each line a unique noise seed,
      // and frameCount animates it over time.
      let noiseValue = noise(i * 0.1, j * 0.1, frameCount * 0.01);
      
      // Map the noise value (0 to 1) to an angle (0 to 4*PI)
      let angle = map(noiseValue, 0, 1, 0, TWO_PI * 2);
      
      let len = spacing * 1.2;
      
      rotate(angle);
      strokeWeight(2);
      line(-len / 2, 0, len / 2, 0);
      
      pop();
    }
  }
}